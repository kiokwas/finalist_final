#include <stdio.h>

void main()
{
    puts("igoh25{5b6840936a5e1d680b21966531d8d39d}\n");
}