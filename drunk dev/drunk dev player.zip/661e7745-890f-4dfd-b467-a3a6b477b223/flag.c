#include <stdio.h>

void main()
{
    puts("igoh25{test_flag}\n");
}